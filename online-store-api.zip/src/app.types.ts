export class Collaborate {
    name: string;
    phoneNumber: string;
    contactMethod: string;
}